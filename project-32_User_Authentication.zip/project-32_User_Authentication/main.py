from flask import Flask, render_template, request, url_for, redirect, flash, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import Integer, String
from flask_login import UserMixin, login_user, LoginManager, login_required, current_user, logout_user

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret-key-goes-here'
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# CREATE DATABASE


class Base(DeclarativeBase):
    pass


app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(model_class=Base)
db.init_app(app)

# CREATE TABLE IN DB


class User(db.Model):
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(100), unique=True)
    password: Mapped[str] = mapped_column(String(100))
    name: Mapped[str] = mapped_column(String(1000))

with app.app_context():
    db.create_all()

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def home():
    return render_template("index.html")


@app.route('/register', methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        hashed_password = generate_password_hash(password, method="scrypt", salt_length=8)
        print(f"{name} - {email} - {hashed_password}")

        data = db.session.scalars(
            db.select(User).where(User.email == email)
        ).first()

        if not data:
            temp_user = User()
            temp_user.name = name
            temp_user.email = email
            temp_user.password = hashed_password

            db.session.add(temp_user)
            db.session.commit()
            return redirect(url_for('secrets', name=name))

        flash("User already Exist!", "error")
    return render_template("register.html")


@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method=="POST":
        email = request.form['email']
        password = request.form['password']

        data = db.session.scalars(
            db.select(User).where(User.email == email)
        ).first()

        if data and check_password_hash(data.password, password):
            return redirect(url_for('secrets', name=data.name))
        else:
            flash("Invalid Email or Password", "error")
    return render_template("login.html")


@app.route('/secrets/<name>')
def secrets(name):
    return render_template("secrets.html", name=name)


@app.route('/logout')
def logout():
    pass


@app.route('/download', methods=["GET"])
def download():
    return send_from_directory(
        directory='static/files',
        path="cheat_sheet.pdf",
        as_attachment=True
    )


if __name__ == "__main__":
    app.run(debug=True)
