from flask import Flask, render_template, redirect, url_for, request
from flask_bootstrap import Bootstrap5
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import Integer, String, Float
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.fields.numeric import FloatField, IntegerField
from wtforms.validators import DataRequired
from sqlalchemy import desc
import requests

API_KEY = "77b27b8d92cc67db1c413a0c07f6983e"
API_ADDRESS = "https://api.themoviedb.org/3/search/movie?api_key=YOUR_API_KEY&query=movie_title&include_adult=false&language=en-US&page=1"

app = Flask(__name__)
app.config['SECRET_KEY'] = '8BYkEfBA6O6donzWlSihBXox7C0sKR6b'

Bootstrap5(app)

# CREATE DB
class Base(DeclarativeBase):
    pass
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
data_base_access = SQLAlchemy(model_class=Base)
data_base_access.init_app(app)

class MovieTable(data_base_access.Model):
    id = data_base_access.Column(data_base_access.Integer, primary_key=True)
    title = data_base_access.Column(data_base_access.String(50), nullable=False, unique=True)
    year = data_base_access.Column(data_base_access.Integer, nullable=False)
    description = data_base_access.Column(data_base_access.String(200), nullable=True)
    rating = data_base_access.Column(data_base_access.Float, nullable=False)
    ranking = data_base_access.Column(data_base_access.Integer, nullable=False)
    review = data_base_access.Column(data_base_access.String(200), nullable=False)
    img_url = data_base_access.Column(data_base_access.String(200), nullable=False)


# CREATE TABLE

# CREATED AN INSTANCE
with app.app_context():
    data_base_access.create_all()

data1 = MovieTable(
    title="Pushpa - 2",
    year=2024,
    description="Pushpa 2: The Rule is a 2024 Indian Telugu-language action drama film written and directed by Sukumar, and produced by Mythri Movie Makers, in association with Sukumar Writings. ",
    rating=9.2,
    ranking=8,
    review="My favourite character was the Shikawat Singh",
    img_url="https://imgs.search.brave.com/0hQ1C78Xu1O_6dYTjznjShRBIL0JpADcfxFdbFx30K8/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9tLm1l/ZGlhLWFtYXpvbi5j/b20vaW1hZ2VzL00v/TVY1Qk5EYzBNR1Zt/TURNdE5tRTNOQzAw/WmpabUxXRTVaVEV0/WXpFd04ySmpOV1ps/TW1SbVhrRXlYa0Zx/Y0djQC5qcGc"
)
#
# with app.app_context():
#     data_base_access.session.add(data1)
#     data_base_access.session.commit()

class my_form(FlaskForm):
    rating = FloatField('Rating', validators=[DataRequired()])
    review = StringField('Review', validators=[DataRequired()])
    submit = SubmitField('Done')

class add_movie_form(FlaskForm):
    movie_tite = StringField('Movie Title', validators=[DataRequired()])
    year = IntegerField('Year', validators=[DataRequired()])
    description = StringField('Description', validators=[DataRequired()])
    rating = FloatField('Rating', validators=[DataRequired()])
    ranking = IntegerField('Rank', validators=[DataRequired()])
    review = StringField('Review', validators=[DataRequired()])
    img_url = StringField('URL', validators=[DataRequired()])
    submit = SubmitField('Add Movie')

def activate_data():
    with app.app_context():
        data_base_access.session.add(data1)
        data_base_access.session.commit()

def retrieve_data():
    data = MovieTable.query.all()
    return data

def arrange_data():
    sorted_data = MovieTable.query.order_by(desc(MovieTable.rating)).all()
    for index, movie in enumerate(sorted_data, start=1):
        movie.ranking = index
        data_base_access.session.commit()
    return sorted_data

@app.route("/")
def home():
    # activate_data()
    return render_template("index.html", data=arrange_data())

@app.route("/edit", methods=["POST", "GET"])
def edit_function():
    form = my_form()
    movie_id = int(request.args.get("id"))
    if form.validate_on_submit():
        movie_to_edit = MovieTable.query.get(movie_id)
        movie_to_edit.rating = form.rating.data
        movie_to_edit.review = form.review.data
        data_base_access.session.commit()
        return redirect(url_for('home'))

    all_data = retrieve_data()
    required_data = all_data[movie_id-1]
    return render_template('edit.html', movie_name = required_data.title, form = form)

@app.route('/delete')
def delete_function():
    movie_id = int(request.args.get("id"))
    movie_to_delete = MovieTable.query.get(movie_id)
    if movie_to_delete:
        data_base_access.session.delete(movie_to_delete)
        data_base_access.session.commit()
    return redirect(url_for('home'))

@app.route('/add_movie', methods=["POST", "GET"])
def add_movie():
    form = add_movie_form()
    if form.validate_on_submit():
        data1.title = form.movie_tite.data
        data1.review = form.review.data
        data1.rating = form.rating.data
        data1.img_url = form.img_url.data
        data1.year = form.year.data
        data1.description = form.description.data
        activate_data()
        return redirect(url_for('home'))
    return render_template("add.html", form=form)

if __name__ == '__main__':
    app.run(debug=True)
