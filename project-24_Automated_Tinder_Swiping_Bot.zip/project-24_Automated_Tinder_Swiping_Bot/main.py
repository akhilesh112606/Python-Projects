from selenium import webdriver
from selenium.common import NoSuchElementException, ElementClickInterceptedException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# KEEPS THE CHROME  BROWSER OPEN EVEN WHEN THE CODE IS FINISHED
chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("detach", True)

driver = webdriver.Chrome(options=chrome_options)
driver.get("https://tinder.com/deeplink/account-recovery/confirm/eyJhbGciOiJIUzI1NiJ9.aWFtYWtoaWx5dDIwMDVAZ21haWwuY29tLXJlY292ZXJ5X2VtYWlsX290cA.FLDTgxoAUcstYw9YQWt_GENHhAqBjCyHBwx76S16wqc")

time.sleep(10)

cookie_accept = driver.find_element(By.XPATH, "//*[@id='q18919352']/div/div[2]/div/div/div[1]/div[1]/button")
cookie_accept.click()

mobile_number_box = driver.find_element(By.ID, "phone_number")
mobile_number_box.send_keys("") # ENTER YOUR LOGIN CREDENTIALS

submit_button = driver.find_element(By.XPATH, "//*[@id='q18919352']/div/div/div[1]/div/div[3]/button")
submit_button.click()

time.sleep(15)

location_allow = driver.find_element(By.XPATH, "//*[@id='q18919352']/div/div/div/div/div[3]/button[1]")
location_allow.click()

time.sleep(2)
notification_popup = driver.find_element(By.XPATH, "//*[@id='q18919352']/div/div/div/div/div[3]/button[2]")
notification_popup.click()

like_button = driver.find_element(By.XPATH, "//*[@id='q1747300428']/div/div[1]/div/div/div/main/div/div/div[1]/div/div[3]/div/div[4]/button")
condition = True
for i in range(100):
    time.sleep(1)
    try:
        like_button.click()
    except NoSuchElementException:
        time.sleep(2)
    except ElementClickInterceptedException:
        try:
            its_a_match = driver.find_element(By.CSS_SELECTOR, ".itsAMatch a")
            its_a_match.click()

        except:
            time.sleep(2)
driver.quit()