from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# KEEPS THE CHROME BROWSER OPEN EVEN WHEN THE CODE IS FINISHED
chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("detach", True)

# CREATE AND CONFIGURE THE CHROME WEBDRIVER
driver = webdriver.Chrome(options=chrome_options)
driver.get("https://www.linkedin.com/login")

time.sleep(5)

# LOGGING IN INTO OUR ACCOUNT
email_input = driver.find_element(By.XPATH, "//*[@id='username']")
password_input = driver.find_element(By.XPATH, "//*[@id='password']")
signup_button = driver.find_element(By.CLASS_NAME, "btn__primary--large")

time.sleep(2)
email_input.send_keys("iamakhilyt2005@gmail.com")
password_input.send_keys("@nu4!eP67")
signup_button.click()

time.sleep(20)
job_button = driver.find_element(By.XPATH, "//*[@id='global-nav']/div/nav/ul/li[3]/a")
job_button.click()

time.sleep(5)
search_button = driver.find_element(By.CSS_SELECTOR, ".jobs-search-box__text-input.jobs-search-box__keyboard-text-input.jobs-search-global-typeahead__input")
search_button.send_keys("Python Developer")
search_button.send_keys(Keys.ENTER)

time.sleep(5)
easy_apply_button = driver.find_element(By.CSS_SELECTOR, ".jobs-apply-button.artdeco-button.artdeco-button--3.artdeco-button--primary.ember-view")
easy_apply_button.click()

time.sleep(5)
mobile_number = driver.find_element(By.CSS_SELECTOR, ".artdeco-text-input--input")
mobile_number.send_keys("8463915216")

next_button = driver.find_element(By.CSS_SELECTOR, ".artdeco-button.artdeco-button--2.artdeco-button--primary.ember-view")
next_button.click()

next_button_two = driver.find_element(By.CSS_SELECTOR, ".artdeco-button.artdeco-button--2.artdeco-button--primary.ember-view")
next_button_two.click()

time.sleep(5)
dialogue_box_one = driver.find_element(By.XPATH, "//*[@id='radio-button-form-component-formElement-urn-li-jobs-applyformcommon-easyApplyFormElement-4055735634-8527856386-multipleChoice']/div[1]/label")
dialogue_box_one.click()

time.sleep(2)
review_box = driver.find_element(By.CSS_SELECTOR, ".artdeco-button.artdeco-button--2.artdeco-button--primary.ember-view")
review_box.click()

time.sleep(3)
submit_application_button = driver.find_element(By.CSS_SELECTOR, ".artdeco-button.artdeco-button--2.artdeco-button--primary.ember-view")
submit_application_button.click()