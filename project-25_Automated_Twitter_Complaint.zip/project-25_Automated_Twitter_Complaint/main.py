import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

PROMISED_DOWN = 150
PROMISED_UP = 10
TWITTER_EMAIL = "saipavankalyan11@gmail.com"
TWITTER_PASSWORD = "abhinav12"
TWITTER_ID = "Abhinav95728397"

chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("detach", True)

driver = webdriver.Chrome(options=chrome_options)
ookla = webdriver.Chrome(options=chrome_options)


ookla.get("https://www.speedtest.net/")
driver.get("https://twitter.com/i/flow/signup")

time.sleep(3)
run = ookla.find_element(By.CSS_SELECTOR, ".js-start-test.test-mode-multi")
run.click()

time.sleep(30)
download_mbps = ookla.find_element(By.CSS_SELECTOR, ".result-data-large.number.result-data-value.download-speed")
download_text = download_mbps.text

upload_mbps = ookla.find_element(By.CSS_SELECTOR, ".result-data-large.number.result-data-value.upload-speed")
upload_text = upload_mbps.text


time.sleep(5)
login_button = driver.find_element(By.CSS_SELECTOR, ".css-1jxf684.r-bcqeeo.r-qvutc0.r-poiln3.r-fdjqy7")
login_button.click()

time.sleep(5)
username_input = driver.find_element(By.CSS_SELECTOR, ".r-30o5oe.r-1dz5y72.r-13qz1uu.r-1niwhzg.r-17gur6a.r-1yadl64.r-deolkf.r-homxoj.r-poiln3.r-7cikom.r-1ny4l3l.r-t60dpp.r-fdjqy7")
username_input.send_keys(TWITTER_EMAIL)

next_button = driver.find_element(By.CSS_SELECTOR, ".css-175oi2r.r-sdzlij.r-1phboty.r-rs99b7.r-lrvibr.r-ywje51.r-184id4b.r-13qz1uu.r-2yi16.r-1qi8awa.r-3pj75a.r-1loqt21.r-o7ynqc.r-6416eg.r-1ny4l3l")
next_button.click()

time.sleep(3)
phone_number = driver.find_element(By.CSS_SELECTOR, ".r-30o5oe.r-1dz5y72.r-13qz1uu.r-1niwhzg.r-17gur6a.r-1yadl64.r-deolkf.r-homxoj.r-poiln3.r-7cikom.r-1ny4l3l.r-t60dpp.r-fdjqy7")
phone_number.send_keys(TWITTER_ID)

next_button_two = driver.find_element(By.CSS_SELECTOR, ".css-175oi2r.r-sdzlij.r-1phboty.r-rs99b7.r-lrvibr.r-19yznuf.r-64el8z.r-1fkl15p.r-1loqt21.r-o7ynqc.r-6416eg.r-1ny4l3l")
next_button_two.click()

time.sleep(3)
password_input = driver.find_element(By.CSS_SELECTOR, ".r-30o5oe.r-1dz5y72.r-13qz1uu.r-1niwhzg.r-17gur6a.r-1yadl64.r-deolkf.r-homxoj.r-poiln3.r-7cikom.r-1ny4l3l.r-t60dpp.r-fdjqy7")
password_input.send_keys(TWITTER_PASSWORD)

next_button_three = driver.find_element(By.XPATH, "//*[@id='layers']/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div[1]/div/div/button")
next_button_three.click()

# time.sleep(3)
# text_paragraph = driver.find_element(By.XPATH, "//*[@id='react-root']/div/div/div[2]/main/div/div/div/div/div/div[3]/div/div[2]/div[1]/div/div/div/div[2]/div[1]/div/div/div/div/div/div/div/div/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/span/span")

# CUSTOMIZE YOUR OWN TEXTst 150MBPS! So give me some benefits")

print(f"My Internet Service is from JIO, which is currently having {download_text}MBPS"
                         f"But my package guarantees me atleast 150mbps")