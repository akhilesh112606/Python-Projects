from bs4 import BeautifulSoup
import requests
import smtplib
from email.message import EmailMessage

WEBSITE_LINK  = input("Enter the link of AMAZON PRODUCT : ")
TARGET_PRICE = 40000  # Can ask the user if wanted

try:
    website_link = requests.get(url=WEBSITE_LINK)
    print("Website Connected!")
except:
    print("Website Connection Failed!")
    exit()
website_full_html = website_link.text
soup = BeautifulSoup(website_full_html, "html.parser")
product_title_link = soup.find(name="span", class_="a-size-large product-title-word-break", id="productTitle")

product_price_link_dec = soup.find(name="span", class_="a-price-whole")
product_price_str = str(product_price_link_dec.getText())
product_title_temp = str(product_title_link.getText())

product_title = " ".join(product_title_temp.split())
product_price_str = product_price_str.replace(",", "")
product_price_str = product_price_str.replace(".", "")

product_price = int(product_price_str)

print(product_title)
print(product_price)

sender_email = "" # ENTER YOUR DETAILS
body = f"{product_title} is now {product_price} ONLY!"
smtp_server = "smtp.gmail.com"
smtp_port = 587

login_mail = "" # ENTER YOUR DETAILS
login_app_password = "" # ENTER YOUR DETAILS
receiver_mail = "" # ENTER YOUR DETAILS

if product_price < TARGET_PRICE:
    msg = EmailMessage()
    msg.set_content(body)
    msg['Subject'] = "Price Drop Alert!"
    msg['From'] = sender_email
    msg['To'] = receiver_mail

    try:
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(login_mail, login_app_password)
        server.send_message(msg)
        server.quit()
        print("EMAIL SENT SUCCESSFULLY!")

    except:
        print("EMAIL FAILED! ERROR OCCURED")

