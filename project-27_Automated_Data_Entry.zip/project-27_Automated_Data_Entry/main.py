import time
from http.client import responses
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import requests

ZILLOW_LINK = "https://appbrewery.github.io/Zillow-Clone/"
GOOGLE_FORMS_LINK = "https://forms.gle/bv42EpXhzWcyA8tn6"

response = requests.get(url=ZILLOW_LINK)
soup = BeautifulSoup(response.text, "html.parser")

# EXTRACTING ALL THE PROPERTY LINKS
all_property_cards = soup.find_all(class_="property-card-link", tabindex="-1")
all_property_link = []
for card in all_property_cards:
    temp_link = card['href']
    all_property_link.append(temp_link)
print(all_property_link)

# EXTRACTING ALL THE ADDRESS
all_address_cards = soup.find_all("address")
all_address = []
for address in all_address_cards:
    temp_address = address.getText()
    temp_address = ' '.join(temp_address.split())
    all_address.append(temp_address)
print(all_address)

# EXTRACTING OF THE PRICES
all_prices_cards = soup.find_all(class_="PropertyCardWrapper__StyledPriceLine")
all_prices = []
for price in all_prices_cards:
    temp_price = price.getText()
    temp_price = temp_price.replace("+/mo", "")
    temp_price = temp_price.replace("+1 bd", "")
    temp_price = temp_price.replace("/mo", "")
    temp_price = temp_price.replace("bd", "")
    temp_price = temp_price.replace("+ 1", "")
    all_prices.append(temp_price)
print(all_prices)

# OPENING THE GOOGLE FORMS & CONTROLLING IT
chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option("detach", True)
driver = webdriver.Chrome(options=chrome_options)

driver.get(url=GOOGLE_FORMS_LINK)
time.sleep(2)

for loop_price, loop_address, loop_link in zip(all_prices, all_address, all_property_link):
    all_questions = driver.find_elements(By.CSS_SELECTOR, ".whsOnd.zHQkBf")
    all_questions[0].send_keys(f"{loop_address}")
    all_questions[1].send_keys(f"{loop_price}")
    all_questions[2].send_keys(f"{loop_link}")

    submit_button = driver.find_element(By.XPATH, "//*[@id='mG61Hd']/div[2]/div/div[3]/div[1]/div[1]/div")
    submit_button.click()
    time.sleep(2)

    submit_another_response = driver.find_element(By.XPATH, "/html/body/div[1]/div[2]/div[1]/div/div[4]/a")
    submit_another_response.click()
    time.sleep(2)
