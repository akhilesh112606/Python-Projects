import requests
from pprint import pprint

class DataManager:
    def __init__(self):
        self.connection_getdata = requests.get(url="https://api.sheety.co/554050451660d9d5f3feaa21346bb707/akhilFlightDeal/sheet1")
        self.data = self.connection_getdata.json()
        print(self.data)

    def get_sheet_data(self):
        return self.data

    def update_sheet_data(self, row_id, content):
        temp_json = {"sheet1" : content}
        self.connection_row_edit = requests.put(url = f"https://api.sheety.co/554050451660d9d5f3feaa21346bb707/akhilFlightDeal/sheet1/{row_id}", json=temp_json)


