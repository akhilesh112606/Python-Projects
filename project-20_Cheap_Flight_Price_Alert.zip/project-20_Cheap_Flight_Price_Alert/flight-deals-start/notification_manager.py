import datetime
from pyexpat.errors import messages
from twilio.rest import Client
class NotificationManager:
    def __init__(self):
        self.account_sid = "ACb1308652e5861b7694901fe1d73680a2"
        self.auth_token = "bd636e743156de20f296a84196df1358"


    def send_sms(self, price, departure_to, departure_from, date):
        client = Client(self.account_sid, self.auth_token)
        message = client.messages.create(
            to='+918463915216',
            from_='+19707075302',
            body= f"Low Price Alert! Only {price}$ to fly from {departure_from} to {departure_to}, on {datetime.datetime.now().strftime('%Y-%m-%d')} until {date}" # HAS TO BE FILLED
        )
        print(f"Low Price Alert! Only {price}$ to fly from {departure_from} to {departure_to}, on {datetime.datetime.now().strftime('%Y-%m-%d')} until {date}")
