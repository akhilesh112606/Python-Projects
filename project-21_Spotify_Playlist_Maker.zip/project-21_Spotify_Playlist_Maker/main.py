import requests
import spotipy
from spotipy import SpotifyOAuth
from datetime import datetime
from bs4 import BeautifulSoup

Client_ID = "23e5164d2c754ca28622bdf3b48a3c19"
Client_Secret = "42d2bdf79ddd4c3db497416dc99e475e"
Spotify_Username = "31lphqcf3lnwmr5ypj7enx3bpy4a"

date = str(input("Which year do you want to travel to? Type the date in YYYY-MM-DD format : "))
date_format = "%Y-%m-%d"
try:
    valid_date = datetime.strptime(date, date_format)
except ValueError:
    print("The date is not in the correct format!")
    exit()

website_req = requests.get(url=f"https://www.billboard.com/charts/hot-100/{date}", headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0"})
website_html_data = website_req.text
soup = BeautifulSoup(website_html_data, "html.parser")
songs_list_div = soup.select("li ul li h3")
songs_list = []
for song in songs_list_div:
    temp_song_name = str(song.getText()).strip()
    songs_list.append(temp_song_name)

spotify_auth = SpotifyOAuth(client_id=Client_ID, client_secret=Client_Secret, redirect_uri="http://example.com", scope="playlist-modify-private", show_dialog=True, cache_path="token.txt")
spotify_auth.get_auth_response()

## FINDING URI
spotify = spotipy.Spotify(auth_manager=spotify_auth)

songs_uri_list = []
for song_name in songs_list:
    try:
        json_data = spotify.search(q=song_name, type='track', limit=1)
        temp_uri = json_data['tracks']['items'][0]['uri']
        songs_uri_list.append(temp_uri)

    except:
        print(song_name+" not available")
        continue

playlist_response = spotify.user_playlist_create(user=Spotify_Username, name=f"{date} BillBoard 100", description="", public=False)
Playlist_ID = playlist_response['id']

## Adding songs to the Playlist
# for song_uri in songs_uri_list:
#     # spotify.playlist_add_items(playlist_id=Playlist_ID, items=song_uri)
spotify.playlist_add_items(playlist_id=Playlist_ID, items=songs_uri_list)